# frozen_string_literal: true

require 'csv'
require 'tty-prompt'
require_relative 'stations.rb'
require_relative 'stops.rb'
require_relative'trains.rb'
require_relative'train.rb'
def main
  csv = CSV.read('stops.csv')
  stops = Stops.new
  number = []
  trains = Trains.new
  a = 0
  csv.each do |row|
    if (a = 0)
        a = 1
        next
    end
    stops.add(row)
    stop = row
    if number.include?(stop[0])
        trains[number.index[stop[0]]].add_stop(stop)
      else
        number.append(stop[0])
        train = Train.new(stop[0], stop[1])
        trains.add(train)
      end
  end
  csv2 = CSV.read('stations.csv')
  stations = Stations.new
  csv2.each do |row|
    stations.add(row)
  end
  choices = { "\xD0\xA0\xD0\xB0\xD1\x81\xD0\xBF\xD0\xB8\xD1\x81\xD0\xB0\xD0\xBD\xD0\xB8\xD0\xB5" => 1, "\xD0\xA1\xD0\xBF\xD0\xB8\xD1\x81\xD0\xBE\xD0\xBA" => 2, "\xD0\x9A\xD0\xBE\xD0\xBD\xD0\xB5\xD1\x86" => 3 }
  prompt = read_in
    
  switch_choices(prompt.select('Menu', choices), trains, prompt)
end

def read_in
  prompt = TTY::Prompt.new
end

def switch_choices(num, trains, prompt)
  if num == 1
    choices = trains
    choice = prompt.select('Menu2', choices)
    p trains.index(choice)
  end

  if num == 2

  end
  return if num == 3
end
main if __FILE__ == $PROGRAM_NAME
