# frozen_string_literal: true

require_relative 'train.rb'

class Trains
  def initialize
    @trains = []
  end

    def add(new_one)
     @trains.append(new_one)
    end

   def index(train)
    a = 0
    for i in @trains
        if i.number == train.number
            return a
        end
        a +=1
    end
    end
end
