# frozen_string_literal: true

class Train
  def initialize(number, stops)
    @number = number
    @stops = stops
  end
  attr_reader :number
  def add_stop(stop)
    stops.append(stop)
  end
end
