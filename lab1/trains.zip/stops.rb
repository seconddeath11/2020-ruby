# frozen_string_literal: true

class Stops
  def initialize
    @stops = []
  end

  def add(new_one)
    @stops.append(new_one)
    end
end
