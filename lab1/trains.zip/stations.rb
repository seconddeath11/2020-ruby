# frozen_string_literal: true

class Stations
  def initialize
    @stations = []
  end

  def add(new_one)
    @stations.append(new_one)
    end
end
