# frozen_string_literal: true

require_relative 'models/validator'
require_relative 'models/book'
require_relative 'models/book_list'
