# frozen_string_literal: true

# Types of the states
module StateType
  def self.all
    [
      'Работает', 'Простаивает', 'На ремонте'
    ]
  end
end
