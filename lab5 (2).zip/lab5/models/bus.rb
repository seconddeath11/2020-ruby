# frozen_string_literal: true

Bus = Struct.new(:number, :consumption, :name, :rout, :state, keyword_init: true)
