# frozen_string_literal: true

Rout = Struct.new(:name, :stops, :length, :buses, :buses_all, keyword_init: true)
