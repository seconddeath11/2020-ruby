# frozen_string_literal: true

Rout = Struct.new(:name, :stops, :length, :buses, keyword_init: true)
